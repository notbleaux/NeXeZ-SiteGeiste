# PR: NueVue — Roadmap & Architecture v0.2

**Status:** DRAFT — awaiting human approval before Phase 1 execution
**Author:** Claude (acting Foreman)
**Date:** 2026-05-09
**Supersedes:** v0.1
**Carries forward:** identity model, auth flow, invite system, verification pipeline, two-database split (all unchanged)

---

## 0. Summary of changes from v0.1

| Change | Reason |
|---|---|
| **Application shell = Discord paradigm** | User: private "server-to-self", left rail = services, main pane = content |
| **Content pages = Notion paradigm** | User: modular blocks, linked databases, backlinks, library modular control. No podcasts. |
| **Backend = broker pattern** | User: write-through broker, indexed storage, lightweight frontend |
| **Single-tier Claude router → Multi-Vendor AI Service Layer** | User: Claude + Kimi + Deepseek + Copilot + ChatGPT + free-tier floor |
| **NEW: Handoff Service** | User: when an agent becomes unavailable, serialize state and hand off with vendor-tuned prompt |
| **NEW: Persona Registry** | User: generalist / basic / complex personas, OC-specialist, literature-specialist, etc. |
| **NEW: Budget Tracker + weekly analytics** | User: weekly token budgets, AI activity logged, weekly report |
| **NEW: Discord-bot Framework phase** | User: Discord API/app paradigm as native base for extensibility |
| **NEW: Notion-style Content Networking phase** | User: backlinks, linked databases, modular page composer |
| Phase plan: 15 → 17 phases | Reflects added scope |

---

## 1. Locked decisions (cumulative)

1. Project name: **NueVue**.
2. Canonical format: hybrid Markdown + YAML frontmatter, deterministic projections.
3. Identity model: Account-ID (private) + User-IDK (public) + Display Name (optional alias) + User-Details (encrypted). Real names never rendered.
4. Default user records: Username `ILILIX`, IDK `leBeauxBleaux`. Author display for EBB corpus = `"E.B.B."` with `persona_of: leBeauxBleaux`.
5. Auth: Password (coldstart) + PIN (warm sessions) with measurable AFK step-up triggers.
6. Invite system: 24h TTL, single-use, server-enforced concurrency rule, masked history.
7. Two databases: DB1 (Library, canonical works) + DB2 (Review Archive, AI-generated reviews).
8. Verification pipeline: Producer → Reviewer → Arbiter (Foreman) → Human gate.
9. Foreman authority: discernment for problem-solving and adaptation; never bypass human gates.
10. **NEW:** UI shell = Discord paradigm, content pages = Notion paradigm, backend = broker pattern.
11. **NEW:** AI service layer is multi-vendor with documented handoff, personas, and budget tracking.
12. **NEW:** AI tier defaults: Claude-Haiku base, Sonnet on escalation, Opus on user confirm. Conservative budgets. Phase 11 tunes.

---

## 2. Architecture

### 2.1 Application architecture (NEW)

```
┌──────────────────────────────────────────────────────────────────┐
│ FRONTEND (lightweight: HTMX or lean Svelte; SSR-first)           │
│   ┌─────────────┬──────────────────────────────┬───────────────┐ │
│   │ Left Rail   │ Main Pane (Notion-style)     │ Right Pane    │ │
│   │ (Discord)   │  - Modular blocks            │ (optional)    │ │
│   │  Services:  │  - Linked databases          │  - AI chat    │ │
│   │  • Library  │  - Backlinks                 │  - Context    │ │
│   │  • Reader   │  - Page composer             │  - Notes      │ │
│   │  • Editor   │  Sub-nav (channels):         │               │ │
│   │  • Reviews  │   Library → Set A → Batch 01 │               │ │
│   │  • Learn    │                              │               │ │
│   │  • AI       │                              │               │ │
│   │  • Bots     │                              │               │ │
│   │  • Dash     │                              │               │ │
│   └─────────────┴──────────────────────────────┴───────────────┘ │
└─────────────────────────────────┬────────────────────────────────┘
                                  │ HTTP/WebSocket
┌─────────────────────────────────▼────────────────────────────────┐
│ APPLICATION LAYER (FastAPI services)                              │
│  Reader │ Editor │ Library │ Reviews │ Learn │ AI │ Bots │ Dash  │
└──────────┬──────────────────────────────────────────┬────────────┘
           │                                          │
           ▼                                          ▼
┌────────────────────┐                    ┌────────────────────────┐
│ AI SERVICE LAYER   │                    │ BROKER (event bus)     │
│ - Tier Router      │                    │ - Write-through queue  │
│ - Vendor Adapters  │                    │ - Index updater        │
│ - Handoff Service  │                    │ - Audit logger         │
│ - Persona Registry │                    │ - Backup trigger       │
│ - Budget Tracker   │                    └─────────┬──────────────┘
└─────────┬──────────┘                              │
          │                                         ▼
          │                              ┌────────────────────────┐
          │                              │ STORAGE                │
          │                              │ - DB1 Library (.md)    │
          │                              │ - DB2 Reviews (.md)    │
          │                              │ - SQLite index         │
          │                              │ - Audit log            │
          │                              │ - Drive sync mirror    │
          │                              └────────────────────────┘
          │
          ▼
┌──────────────────────────────────────────────────────────────────┐
│ EXTERNAL VENDORS                                                  │
│ Anthropic │ Moonshot(Kimi) │ Deepseek │ Copilot │ ChatGPT │       │
│                       Ollama (local) │ Free-tier APIs            │
└──────────────────────────────────────────────────────────────────┘
```

**Why broker pattern:**
- Writes are events. Broker fans out to storage + index + audit log + (optionally) Drive sync. Frontend is decoupled from storage latency.
- Reads go through indexed retrieval, not file-system scans. SQLite index keeps lookup <50ms even at 10K+ assets.
- Audit log is automatic — every write is observable.
- Failure isolation: if Drive sync fails, writes still succeed locally; sync retries.

### 2.2 AI Service Layer (NEW)

#### 2.2.1 Vendor map

| Vendor | Tier role | Strengths used | Limits |
|---|---|---|---|
| Claude (Opus) | Primary, high-stakes | Considered review, synthesis, final critique | Burns tokens; user-confirm or escalation only |
| Claude (Sonnet) | Primary, mid | Reasoning, structured tasks | Default escalation target |
| Claude (Haiku) | Primary, base | Quick reasoning, classification | Default starting tier |
| Kimi (Moonshot) | Primary, equal weight | Massive context, swarm/parallel sub-agents, bulk labour | Used for batch OCR, large-context summarization |
| Deepseek | Secondary | Standard large-context tasks | Promoted to primary if Claude+Kimi both unavailable |
| Copilot | Auxiliary | Prompt refinement, planning, routine code | Never final review, never critical |
| ChatGPT | Auxiliary | Tertiary fallback | After Deepseek |
| Ollama (local) | Floor | Self-hosted Llama/Mistral/Qwen for free fallback | When paid budgets exhausted |
| Free-tier APIs | Floor | OpenRouter free / Groq free / etc. | Last resort, weekly until reset |

#### 2.2.2 Routing logic

```
def route(task, persona, context):
    candidates = persona.preferred_vendors  # ranked list per persona
    for vendor in candidates:
        if vendor.available() and budget.allows(vendor, task.estimated_cost):
            return vendor
    # All preferred unavailable or over-budget
    return fallback_chain(task, context)

def fallback_chain(task, context):
    chain = [Claude_Sonnet, Kimi, Deepseek, Copilot, ChatGPT, Ollama_local, FreeAPI]
    for vendor in chain:
        if vendor.available() and budget.allows(vendor, task.estimated_cost):
            return vendor
    raise NoAvailableVendor  # surfaces to user; never silent fail
```

#### 2.2.3 Handoff Service

When the active vendor becomes unavailable mid-task (rate limit, downtime, budget exhausted), handoff:
1. Serialize conversation state: messages, tool calls, partial outputs, working notes.
2. Produce vendor-tuned handoff prompt (Kimi prefers different framing than Claude; ChatGPT differs again).
3. Inject into next vendor with a "you are continuing work started by X; here is the state and the goal" preamble.
4. Log the handoff event with timestamp, from-vendor, to-vendor, reason, success/failure of resumption.
5. User sees a small UI indicator: "Handed off Claude-Opus → Kimi at 14:32 (rate limit)."

#### 2.2.4 Persona Registry

A persona is a vendor-agnostic prompt + role + tool-permission bundle:

```yaml
persona_id: ebb_specialist
name: "E.B.B. Corpus Specialist"
description: "Deep familiarity with the 571-poem E.B.B. corpus. Used for analysis, cross-references within the corpus, and generating reviews of E.B.B. work."
preferred_vendors: [claude_opus, claude_sonnet, kimi]
tool_permissions: [read_library, write_review_draft, suggest_edit]
system_prompt_template: |
  You are an expert literary analyst with deep familiarity with the E.B.B. corpus...
context_attached: [glossary_setA.md, ebb_corpus_index.json]
```

Personas planned at minimum:
- `generalist` — broad-purpose
- `basic_assistant` — quick tasks, low cost
- `complex_synthesizer` — multi-source reasoning
- `ebb_specialist` — OC corpus expert
- `external_lit_specialist` — others' work expert
- `editor_assistant` — writing help, never overwrites user text
- `learning_coach` — daily prompts, exercise design
- `librarian` — search, retrieval, organization
- `prompt_refiner` — Copilot-led prompt improvement
- `discord_bot_dev` — bot framework helper

#### 2.2.5 Budget Tracker

Per-vendor weekly budgets (user-configurable). Defaults conservative, tunable in Phase 11.

| Vendor | Default weekly cap |
|---|---|
| Claude Opus | $5 |
| Claude Sonnet | $10 |
| Claude Haiku | $5 |
| Kimi | $10 |
| Deepseek | $5 |
| Copilot | $5 (or per Microsoft seat allowance) |
| ChatGPT | $5 |
| Ollama | free (local compute) |
| Free APIs | free (rate limits apply) |
| **Global cap** | $50 / week |

Behavior:
- Soft cap at 80% → warning + auto-downgrade preference for that vendor.
- Hard cap at 100% → vendor removed from candidate list until weekly reset.
- Weekly reset at user-chosen day/time (default Sunday 00:00 user-local).
- Weekly analytics auto-generated: tokens used per vendor, cost per vendor, tasks completed per vendor, handoffs triggered, budget utilization, anomalies.

### 2.3 Notion-style Content Networking (NEW)

Concepts implemented as native NueVue features (not via Notion API):
- **Modular blocks:** paragraph, heading, list, quote, code, callout, image, embed, database-view, link-mention.
- **Linked databases:** any page can embed a filtered view of a database (e.g. "all poems tagged `longing`" embedded inside a thematic essay).
- **Backlinks:** every reference creates a bidirectional link; the referenced page shows "linked by" panel automatically.
- **Modular page composer:** drag/drop or keyboard-driven block composition.
- **Properties:** structured fields on pages (status, tags, dates) that participate in database views.

The canonical schema's `analysis.cross_references` and `reviews` arrays are the data source for backlinks. The frontend renders them as a "Connected Works" and "Reviews" panel on every poem page.

### 2.4 Discord-bot Framework (NEW, pending clarification)

Two interpretations possible — final scope locked at Phase 16:
- **Native paradigm:** Discord-style developer surface (slash commands, webhooks, events, bot personas) implemented inside NueVue. No actual Discord servers needed. Bots run as services on NueVue's broker.
- **Hybrid:** Native paradigm + optional bridge to actual Discord servers via Discord API for users who want to run bots in real Discord.

Either way, Phase 16 delivers:
- Bot SDK (Python or TypeScript) with Discord-like primitives.
- Bot registry + admin UI in the Bots service.
- Event bus integration (bots subscribe to events on the broker).
- Per-bot permission scopes.
- Example bots: daily-prompt bot, review-generator bot, citation-checker bot.

### 2.5 Two-database split (carry over from v0.1)
[Unchanged — see v0.1 §2.1]

### 2.6 Identity, auth, invites, verification (carry over from v0.1)
[Unchanged — see v0.1 §2.2–2.5]

---

## 3. Service inventory (expanded)

| # | Service | Role | Phase |
|---|---|---|---|
| 1 | Library | Browse, search, manage canonical works | 7 |
| 2 | Reader | Virtual book reader, .md/.pdf/.docx | 9 |
| 3 | Editor | Write, edit, export | 10 |
| 4 | Reviews | Browse + generate reviews (DB2) | 6, 12 |
| 5 | Learn | Daily prompts, modules, exercises | 12 |
| 6 | AI | Chat, persona selection, vendor routing | 11 |
| 7 | Bots | Bot dev, registry, admin | 16 |
| 8 | Dashboards | DB stats, AI activity, security, admin | 7, 13 |
| 9 | Settings | Account, auth, AI prefs, budget | 8, 11 |
| 10 | Drive Sync | Two-way sync with Google Drive | 15 |

---

## 4. Phase plan (17 phases, restructured)

Each phase ends with a human-review gate.

| # | Phase | Vertical slice | Gate criteria |
|---|---|---|---|
| 1 | Schema lock + first canonical sample | Build script v0.1 + EBB-01-001 + all six projections | Schema accepted; round-trip integrity |
| 2 | Set A full pass | 571 EBB poems → canonical + projections | 100% files valid; ≥99.5% round-trip; no real-name leakage |
| 3 | Set B triage | IMG_0030–1286 classified | Every file classified with confidence |
| 4 | Set B extraction | OCR + attribution | 100% attribution OR `attribution_unknown` flagged |
| 5 | Set C cleanup + glossary v2 | 26 hex/temp resolved; glossary cross-linked | Bidirectional links verified |
| 6 | Analysis layer (DB1) + Review archive seed (DB2) | Set A analysis populated; first reviews in DB2 with citations | Schema validates; cross-refs resolve |
| 7 | Backend API + landing dashboard + broker | FastAPI service, broker pattern, Discord-shell UI scaffold, landing shows DB stats | Routes <200ms p50; broker idempotent |
| 8 | Auth + invite system | Account creation, password+PIN, invite registry | Adversarial test passes |
| 9 | Reader (virtual book) | Loads .md/.pdf/.docx, scroll modes, TTS | All formats render; dictation works |
| 10 | Editor | WYSIWYG, Word/Docs round-trip, exports | Round-trip preserves formatting |
| 11 | **Multi-Vendor AI Service Layer** | Tier router + vendor adapters + handoff + persona registry + budget tracker + fallback chain + readme overlay + settings | All vendors callable; handoff verified across ≥2 pairs; budget caps enforce; weekly analytics generate |
| 12 | AI-assisted Learning | Reviews, modules, daily writing+poetry prompts | Prompts generate; progress logged |
| 13 | Progress & analytics + AI activity dashboards | Per-user trends, comparative author study, weekly AI report | Dashboards render; weekly report auto-generates |
| 14 | **Notion-style Content Networking** | Modular blocks, linked databases, backlinks, page composer | Backlinks bidirectional; database views render; composer keyboard-friendly |
| 15 | Drive integration | OAuth, Docs/Sheets API, two-way sync, conflict UI | 10-cycle round-trip without loss; conflicts surfaced not silenced |
| 16 | **Discord-bot Framework** | Bot SDK, registry, admin UI, event bus subscriptions, example bots | At least 3 example bots functional; per-bot scopes enforced |
| 17 | OKR/CRIT hardening | Full audit; gap close | All P0/P1 closed |

---

## 5. OKRs (expanded)

**Objective:** Private, AI-assisted creative writing studio with Discord-shell UI, Notion-content paradigm, indexed personal archive, multi-vendor AI service layer, and Drive backup.

- **KR1:** 100% of `/mnt/project` files indexed with verification chain logged.
- **KR2:** Search median latency <200ms over full corpus.
- **KR3:** Zero AI-initiated mutations to user text.
- **KR4:** Auth+invite passes adversarial test suite.
- **KR5:** Drive sync round-trips without loss across 10 cycles.
- **KR6:** Identity model leaks zero real-name data into any UI render or projection.
- **KR7:** AI cost per session ≤ user-configured cap; per-vendor weekly caps enforced.
- **KR8:** **NEW:** Handoff Service successfully resumes work across ≥4 vendor pairs in test scenarios.
- **KR9:** **NEW:** At least 8 personas defined and dispatchable from UI.
- **KR10:** **NEW:** Backlinks bidirectional and rendered on every page that has incoming references.

---

## 6. CRIT (expanded)

| ID | Risk | Severity | Mitigation |
|---|---|---|---|
| R1 | Set B attribution gaps | Medium | `personal_study` flag; private-only display |
| R2 | OCR error compounding | Medium | Three-stage verification + 10% arbiter sampling |
| R3 | AI cost runaway | High | Per-vendor weekly caps + global ceiling + soft/hard cap behavior + spend log |
| R4 | Drive sync conflict | High | Explicit conflict UI; vector clock; no silent resolution |
| R5 | 26 hex-named files unknown | Low | Sandbox-scan in Phase 5 |
| R6 | Real-name leakage | High | Schema separation + automated grep test in CI |
| R7 | Invite token replay | High | Hash denylist; tested in Phase 8 |
| R8 | PIN brute force | Medium | Rate limit + lockout |
| R9 | Audit log tampering | Medium | Append-only + periodic hash chain |
| R10 | Review-prose drift | High | Two-DB split prevents structurally |
| R11 | **NEW:** Handoff loses context | High | State-serialization tests; ≥4 vendor pair tests required at gate |
| R12 | **NEW:** Vendor outage during critical task | High | Fallback chain + graceful degradation; user notified, never silent |
| R13 | **NEW:** Persona drift across vendors | Medium | Persona system_prompt template versioned; cross-vendor consistency tests |
| R14 | **NEW:** Free-tier rate-limit DoS during budget reset gap | Medium | Local Ollama as ultimate floor; if Ollama unavailable, gracefully refuse with clear UX |
| R15 | **NEW:** Broker queue backlog | Medium | Bounded queue with drop-oldest policy on overflow + alert |
| R16 | **NEW:** Backlink infinite loops | Low | Cycle detection in renderer |
| R17 | **NEW:** Discord-bot scope creep | Medium | Lock interpretation (paradigm vs hybrid) at Phase 16 start |

---

## 7. Open questions before Phase 1 + Phase 11 + Phase 16

### Blocking Phase 1 (still pending from v0.1):
1. Approve PR v0.2 architecture + phase plan?
2. Schema v0.1 — accepted, edits, or re-walk?
3. Phase 1 batch reporting format — chat summary + report file, full table, or files only?

### New, blocking Phase 11:
4. Free-tier specifics: Ollama models you have or want installed? Free APIs to register (OpenRouter, Groq, Cerebras, HuggingFace)?
5. Per-vendor weekly budget caps — accept defaults, or specify?
6. Soft cap behavior — auto-downgrade only, or also notify? Hard cap behavior — block or hard-floor to free tier?
7. Weekly reset day/time?

### New, blocking Phase 16:
8. Discord-bot scope: native paradigm only, or hybrid (paradigm + optional real-Discord bridge)?

---

## 8. Foreman's note

This PR replaces v0.1 as the operating plan. v0.1 is preserved in the project as historical record. I will not begin Phase 1 execution until you approve v0.2. Phases 11 and 16 carry their own clarifying questions that must be answered before those phases begin, but Phase 1 can proceed without them.

If during any phase I identify a design gap, I will pause, document it, propose a fix, and request your decision rather than improvising silently. Sub-agent passes and verification reports will be surfaced at every gate so you can drill in.
