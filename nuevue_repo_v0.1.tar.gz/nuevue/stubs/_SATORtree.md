---
satortree_id: "NUEVUE-MAIN"
version: 0.1
canonical: true
created: 2026-05-09
last_updated: 2026-05-09
checksum: null  # filled by validator
---

# SATORtree — NueVue Master Tree

The canonical organizational structure for all NueVue stubs and phase gates.

```
NueVue
│
├── PHASE 1 — Schema lock + first canonical sample [GATE: open]
│   ├── STUB-PHASE-01-S01  Build canonical→projections script v0.1     [sealed] P0
│   ├── STUB-PHASE-01-S02  Author EBB-01-001 canonical .md             [sealed] P0
│   ├── STUB-PHASE-01-S03  Round-trip integrity test harness           [sealed] P0
│   └── STUB-PHASE-01-S04  Phase 1 batch report (chat+file+table)      [sealed] P1
│
├── PHASE 2 — Set A full pass (571 EBB poems) [GATE: locked, depends Phase 1]
│   ├── STUB-PHASE-02-S01  Batch processor framework                   [sealed] P0
│   ├── STUB-PHASE-02-S02  Set A producer pass (12 batches × ~50)      [sealed] P0
│   ├── STUB-PHASE-02-S03  Set A reviewer pass                         [sealed] P0
│   ├── STUB-PHASE-02-S04  Arbiter sampling + correction integration   [sealed] P0
│   ├── STUB-PHASE-02-S05  Master index aggregator                     [sealed] P1
│   └── STUB-PHASE-02-S06  Set A glossary v1                           [sealed] P1
│
├── PHASE 3 — Set B triage (IMG_0030–1286) [GATE: locked]
│   ├── STUB-PHASE-03-S01  Triage classifier sub-agent                 [sealed] P0
│   ├── STUB-PHASE-03-S02  Confidence scoring rubric                   [sealed] P0
│   └── STUB-PHASE-03-S03  Triage report                               [sealed] P1
│
├── PHASE 4 — Set B extraction [GATE: locked]
│   ├── STUB-PHASE-04-S01  OCR pipeline for non-EBB images             [sealed] P0
│   ├── STUB-PHASE-04-S02  Attribution capture                         [sealed] P0
│   └── STUB-PHASE-04-S03  Permission-status flagging                  [sealed] P0
│
├── PHASE 5 — Set C cleanup + glossary v2 [GATE: locked]
│   ├── STUB-PHASE-05-S01  Hex/temp file sandbox-scan                  [sealed] P0
│   ├── STUB-PHASE-05-S02  Set C resolution log                        [sealed] P1
│   └── STUB-PHASE-05-S03  Glossary v2 (cross-set)                     [sealed] P1
│
├── PHASE 6 — Analysis layer (DB1) + Review archive seed (DB2) [GATE: locked]
│   ├── STUB-PHASE-06-S01  Themes/motifs/symbols extractor             [sealed] P0
│   ├── STUB-PHASE-06-S02  Cross-reference graph builder               [sealed] P0
│   ├── STUB-PHASE-06-S03  First independent review batch (DB2)        [sealed] P0
│   └── STUB-PHASE-06-S04  First composite review batch (DB2)          [sealed] P1
│
├── PHASE 7 — Backend API + landing dashboard + broker + To-Do panel [GATE: locked]
│   ├── STUB-PHASE-07-S01  FastAPI service skeleton                    [sealed] P0
│   ├── STUB-PHASE-07-S02  Broker pattern implementation               [sealed] P0
│   ├── STUB-PHASE-07-S03  Discord-shell UI scaffold                   [sealed] P0
│   ├── STUB-PHASE-07-S04  Landing dashboard with DB stats             [sealed] P1
│   ├── STUB-PHASE-07-S05  Right-panel To-Do basic                     [sealed] P1
│   └── STUB-PHASE-07-S06  /poems /search /stats routes                [sealed] P0
│
├── PHASE 8 — Auth + invite system [GATE: locked]
│   ├── STUB-PHASE-08-S01  4-layer identity model                      [sealed] P0
│   ├── STUB-PHASE-08-S02  Password+PIN flow                           [sealed] P0
│   ├── STUB-PHASE-08-S03  Invite token lifecycle                      [sealed] P0
│   ├── STUB-PHASE-08-S04  AFK step-up + activity tracking             [sealed] P0
│   ├── STUB-PHASE-08-S05  Audit log (append-only + hash chain)        [sealed] P0
│   └── STUB-PHASE-08-S06  Adversarial test suite                      [sealed] P0
│
├── PHASE 9 — Reader (virtual book) [GATE: locked]
│   ├── STUB-PHASE-09-S01  .md/.pdf/.docx loader                       [sealed] P0
│   ├── STUB-PHASE-09-S02  Vertical/horizontal scroll modes            [sealed] P0
│   ├── STUB-PHASE-09-S03  Page-turn animation                         [sealed] P1
│   └── STUB-PHASE-09-S04  TTS dictation                               [sealed] P1
│
├── PHASE 10 — Editor [GATE: locked]
│   ├── STUB-PHASE-10-S01  WYSIWYG editor base                         [sealed] P0
│   ├── STUB-PHASE-10-S02  Word/Docs round-trip                        [sealed] P0
│   ├── STUB-PHASE-10-S03  Export MD/PDF/DOCX/TXT                      [sealed] P0
│   └── STUB-PHASE-10-S04  Image↔text traceability                     [sealed] P1
│
├── PHASE 11 — Multi-Vendor AI Service Layer + Token Economics + PINR + Multi-AI [GATE: locked]
│   ├── 11A — AI Service Core
│   │   ├── STUB-PHASE-11A-S01  Tier router                            [sealed] P0
│   │   ├── STUB-PHASE-11A-S02  Vendor adapters (Claude/Kimi/DS/CP/CG) [sealed] P0
│   │   ├── STUB-PHASE-11A-S03  Handoff Service                        [sealed] P0
│   │   ├── STUB-PHASE-11A-S04  Free-tier adapters (OR/Groq/Cer/HF/Oll)[sealed] P0
│   │   └── STUB-PHASE-11A-S05  Budget Tracker (75/85/95/99/100 + 90 hard) [sealed] P0
│   ├── 11B — Personas + Multi-AI
│   │   ├── STUB-PHASE-11B-S01  Persona Registry + dispatch            [sealed] P0
│   │   ├── STUB-PHASE-11B-S02  Multi-AI Group Chat (private+mutual)   [sealed] P0
│   │   └── STUB-PHASE-11B-S03  Polling + transcript capture           [sealed] P0
│   └── 11C — Token Economics + PINR
│       ├── STUB-PHASE-11C-S01  Token Analytics DB schema              [sealed] P0
│       ├── STUB-PHASE-11C-S02  Daily self-checks                      [sealed] P0
│       ├── STUB-PHASE-11C-S03  Weekly review (DS→Kimi→Claude)         [sealed] P0
│       ├── STUB-PHASE-11C-S04  Monthly + Quarterly report templates   [sealed] P1
│       ├── STUB-PHASE-11C-S05  Quarterly walkthrough sign-off UI      [sealed] P1
│       ├── STUB-PHASE-11C-S06  PINR token spec + issuance             [sealed] P0
│       ├── STUB-PHASE-11C-S07  PINR enforcement at broker             [sealed] P0
│       └── STUB-PHASE-11C-S08  PINR audit + adversarial tests         [sealed] P0
│
├── PHASE 12 — Pixel Art Office [GATE: locked]
│   ├── STUB-PHASE-12-S01  Sprite parts library + composer             [sealed] P0
│   ├── STUB-PHASE-12-S02  Animation system (idle/think/speak/work…)   [sealed] P0
│   ├── STUB-PHASE-12-S03  25%-min mode (thought+speech bubbles)       [sealed] P0
│   ├── STUB-PHASE-12-S04  Full-screen FE/Pkmn-style overlay           [sealed] P0
│   ├── STUB-PHASE-12-S05  Per-session + per-sub-agent regeneration    [sealed] P0
│   └── STUB-PHASE-12-S06  Display gender-skew config (with caveat)    [sealed] P1
│
├── PHASE 13 — AI-Assisted Learning [GATE: locked]
│   ├── STUB-PHASE-13-S01  Daily writing prompt generator              [sealed] P0
│   ├── STUB-PHASE-13-S02  Daily poetry prompt generator               [sealed] P0
│   ├── STUB-PHASE-13-S03  Reviews-of-poems UI                         [sealed] P0
│   └── STUB-PHASE-13-S04  Learning modules + progress logging         [sealed] P1
│
├── PHASE 14 — Progress & analytics + AI activity dashboards [GATE: locked]
│   ├── STUB-PHASE-14-S01  Per-user trend dashboard                    [sealed] P0
│   ├── STUB-PHASE-14-S02  AI activity dashboard                       [sealed] P0
│   ├── STUB-PHASE-14-S03  Token Economics dashboards                  [sealed] P0
│   └── STUB-PHASE-14-S04  Comparative author study view               [sealed] P1
│
├── PHASE 15 — Notion-style Content Networking [GATE: locked]
│   ├── STUB-PHASE-15-S01  Modular block system                        [sealed] P0
│   ├── STUB-PHASE-15-S02  Linked database views                       [sealed] P0
│   ├── STUB-PHASE-15-S03  Backlinks engine                            [sealed] P0
│   └── STUB-PHASE-15-S04  Page composer                               [sealed] P1
│
├── PHASE 16 — Drive integration [GATE: locked]
│   ├── STUB-PHASE-16-S01  OAuth flow                                  [sealed] P0
│   ├── STUB-PHASE-16-S02  Drive Docs API integration                  [sealed] P0
│   ├── STUB-PHASE-16-S03  Drive Sheets API integration                [sealed] P0
│   ├── STUB-PHASE-16-S04  Two-way sync + conflict UI                  [sealed] P0
│   └── STUB-PHASE-16-S05  Nightly automated backup                    [sealed] P1
│
├── PHASE 17 — Discord-bot Framework (native paradigm) [GATE: locked]
│   ├── STUB-PHASE-17-S01  Bot SDK primitives                          [sealed] P0
│   ├── STUB-PHASE-17-S02  Bot registry + admin UI                     [sealed] P0
│   ├── STUB-PHASE-17-S03  Event bus subscriptions via broker          [sealed] P0
│   └── STUB-PHASE-17-S04  Three example bots                          [sealed] P1
│
└── PHASE 18 — OKR/CRIT hardening + Quarterly Review readiness [GATE: locked]
    ├── STUB-PHASE-18-S01  Full audit against PR v0.3                  [sealed] P0
    ├── STUB-PHASE-18-S02  Gap close                                   [sealed] P0
    └── STUB-PHASE-18-S03  Quarterly review walkthrough rehearsal      [sealed] P1
```

## Phase gate close criteria reference

For every phase, the gate closes when:
1. All P0 stubs in the phase reach `status: satisfied`.
2. All P0 deliverables files show `all_checked: true`.
3. P1/P2 stubs deferred OR satisfied (P3 may carry over with note).
4. `human_approved: true` set on the phase gate file by user.

## Inter-phase dependencies (high-level)

- Phases 2–6 sequential (data prep).
- Phase 7 (backend) can begin after Phase 1 (parallel with Phase 2+).
- Phase 8 (auth) depends on Phase 7.
- Phases 9, 10 (Reader, Editor) depend on Phase 7 + 8.
- Phase 11 (AI service) can begin parallel with Phase 7.
- Phase 12 (Pixel Art Office) depends on Phase 11.
- Phase 13 depends on Phases 6, 11.
- Phase 14 depends on Phases 8, 11.
- Phase 15 depends on Phase 7, 14.
- Phase 16 depends on Phase 7, 8.
- Phase 17 depends on Phase 11.
- Phase 18 depends on all prior.

Detailed dependency graph rendered in `docs/visualizations/network-dependencies.mermaid`.
