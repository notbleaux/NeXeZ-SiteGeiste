---
canonical_todo_id: "NUEVUE-MAIN-TODO"
generated_from: "stubs/_SATORtree.md"
last_regenerated: 2026-05-09
---

# NueVue — Canonical To-Do (flat, priority-sorted)

This list is regenerated from `stubs/_SATORtree.md` whenever the tree changes. Do not hand-edit; edit the tree.

## Currently actionable (Phase 1 only — all other phases gated)

| Stub | Title | Priority | Status | Dep met? |
|---|---|---|---|---|
| STUB-PHASE-01-S01 | Build canonical→projections script v0.1 | P0 | sealed | ✓ |
| STUB-PHASE-01-S02 | Author EBB-01-001 canonical .md | P0 | sealed | ✓ |
| STUB-PHASE-01-S03 | Round-trip integrity test harness | P0 | sealed | depends on S01 |
| STUB-PHASE-01-S04 | Phase 1 batch report | P1 | sealed | depends on S01-S03 |

## Phase 1 gate close criteria

- [ ] STUB-PHASE-01-S01 satisfied
- [ ] STUB-PHASE-01-S02 satisfied
- [ ] STUB-PHASE-01-S03 satisfied
- [ ] STUB-PHASE-01-S04 satisfied
- [ ] All deliverables files checked off
- [ ] Human-approved by user

## Phase 2+ stubs (sealed, awaiting Phase 1 gate close)

[See `stubs/_SATORtree.md` §Phase 2-18 for full listing — 70+ stubs across 18 phases.]

## Active sub-agent assignments

None (Phase 1 not yet started). Foreman (Claude) holds Phase 1 directly until handed to sub-agents per stub assignment.

## Recently completed

None.

## Deferred or scope-changed

None.
