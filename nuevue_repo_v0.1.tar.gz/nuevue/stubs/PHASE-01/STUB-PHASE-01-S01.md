---
stub_id: "STUB-PHASE-01-S01"
phase: 1
phase_name: "Schema lock + first canonical sample"
title: "Build canonical→projections script v0.1"

status: "sealed"
priority: "P0"

agent_assignment:
  primary: "claude_foreman"
  sub_agents: []  # Phase 1 handled directly by Foreman; no sub-agents needed
  arbiter: "claude_foreman"

depends_on: []
unblocks: ["STUB-PHASE-01-S02", "STUB-PHASE-01-S03", "STUB-PHASE-02-S01"]

deliverables:
  - id: "D1"
    title: "build/project.py exists, runs, prints help"
    success_metric: "`python build/project.py --help` exits 0 with usage text"
    failure_cases:
      - "Script raises uncaught exception"
      - "Help text missing or malformed"

  - id: "D2"
    title: "Canonical .md → 6 projections deterministic"
    success_metric: "Given a canonical .md input, script emits: <id>.json sidecar, master_index.xlsx row entry, search.json entry, glossary.md entries (themes/motifs/symbols), set-A.md aggregate entry, IMG_XXXX.json metadata sidecar — all six within /projections/"
    failure_cases:
      - "Any of the six projections missing"
      - "Re-running on same input produces non-byte-identical outputs"

  - id: "D3"
    title: "Atomic writes (no partial files)"
    success_metric: "Outputs written to .tmp file then renamed; if interrupted mid-write, no partial file appears at final path"
    failure_cases:
      - "Partial files visible during run"
      - "Crash leaves corrupt output at final path"

  - id: "D4"
    title: "requirements.txt pinned"
    success_metric: "All Python dependencies pinned with == versions; fresh venv install works"
    failure_cases:
      - "Unpinned dependencies"
      - "Install fails on fresh venv"

  - id: "D5"
    title: "Schema validation gate"
    success_metric: "Script rejects canonical .md missing required fields with actionable error message; exit code non-zero"
    failure_cases:
      - "Invalid input silently accepted"
      - "Error messages opaque or generic"

deliverables_file: "deliverables/PHASE-01-S01.md"

gate_at_phase: "PHASE-01"

estimated_effort: "1 session"
opened_at: null
in_progress_at: null
review_at: null
satisfied_at: null
sealed_complete_at: null

version: "0.1"
revision_history: []

sub_agent_runs: []
arbiter_signoff:
  signed: false
  by: null
  at: null
  notes: ""
human_signoff:
  signed: false
  by: null
  at: null

context_files:
  - "docs/architecture/sator-framework.md"
  - "docs/schemas/stub.md"
  - "docs/schemas/canonical-asset.md"     # to be created or copied from prior templates
  - "../template_canonical_empty_v0.2.md" # the empty template
  - "NueVue_Roadmap_PR_v0.3.md"

embedded_questions:
  - question_id: "Q1"
    question: "Build script runtime & dependencies"
    conditions:
      - "Python 3.11+ pinned"
      - "Dependencies: pyyaml, openpyxl, jsonschema, markdown-it-py — all pinned with == versions"
      - "requirements.txt committed"
      - "Deterministic output across runs verified by hash"
    resolved: false
    resolution: ""

  - question_id: "Q5"
    question: "Schema validator implementation"
    conditions:
      - "JSON Schema for canonical asset frontmatter"
      - "Validator runs in CI on every PR"
      - "Rejects malformed files with actionable error"
      - "scripts/stub_validator.py exists and is callable"
    resolved: false
    resolution: ""
---

# STUB-PHASE-01-S01 — Build canonical→projections script v0.1

## Purpose

Establish the deterministic build pipeline that converts canonical Markdown+YAML asset files into the six projections used by NueVue: machine sidecar, master index, search payload, glossary entries, per-set aggregate, and IMG metadata sidecar.

This stub is the foundation for every later phase that processes assets. Phase 2 cannot start until this script works.

## Technical specifications

**Language and runtime:** Python 3.11+. Strictly typed (use type hints). All dependencies pinned in `requirements.txt`.

**Dependencies (pinned):**
```
pyyaml==6.0.1
openpyxl==3.1.2
jsonschema==4.21.1
markdown-it-py==3.0.0
```

**Entry point:** `python -m build.project --input <path> --output projections/`

**Required behaviors:**
1. Parse canonical `.md` files (YAML frontmatter + Markdown body).
2. Validate frontmatter against `docs/schemas/canonical-asset.md` JSON Schema.
3. Emit six projections:
   - `<asset_id>.json` — flat JSON sidecar with all frontmatter fields
   - `master_index.xlsx` — append/update row keyed by `asset_id`
   - `search.json` — append/update entry with text + tags + themes for full-text search
   - `glossary.md` entries — append theme/motif/symbol references with backlinks to `asset_id`
   - `set-A.md` aggregate — append summary entry under appropriate phase batch heading
   - `IMG_<NNNN>.json` — paired metadata sidecar referencing `source_path`
4. All writes atomic: write to `.tmp` then rename. Never leave a partial file at a final path.
5. Idempotent: running on the same input twice produces byte-identical outputs (hash-comparable).
6. Re-runs update existing entries in master_index.xlsx, search.json, glossary.md without duplicating.

**File layout:**
```
build/
  __init__.py
  project.py             # main entry
  schema_validator.py    # JSON Schema validation
  projections/
    __init__.py
    json_sidecar.py
    master_index.py
    search_index.py
    glossary.py
    set_aggregate.py
    img_metadata.py
  utils/
    atomic_write.py
    yaml_io.py
test/
  test_project.py        # round-trip + idempotency tests (lives with STUB-S03)
requirements.txt
```

## Code references

**Atomic write pattern (Python):**
```python
import os, tempfile

def atomic_write(path: str, content: bytes) -> None:
    dir_name = os.path.dirname(path) or "."
    fd, tmp = tempfile.mkstemp(dir=dir_name, prefix=".tmp_", suffix=".part")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(content)
        os.replace(tmp, path)  # atomic on POSIX
    except Exception:
        try: os.unlink(tmp)
        except FileNotFoundError: pass
        raise
```

**YAML frontmatter parse (Python):**
```python
import yaml, re

FM_RE = re.compile(r"^---\n(.*?)\n---\n(.*)$", re.DOTALL)

def parse_canonical(text: str) -> tuple[dict, str]:
    m = FM_RE.match(text)
    if not m:
        raise ValueError("Missing or malformed frontmatter")
    fm = yaml.safe_load(m.group(1))
    body = m.group(2)
    return fm, body
```

**JSON Schema validation (Python):**
```python
import jsonschema, json

def validate_asset_frontmatter(fm: dict, schema_path: str) -> None:
    with open(schema_path) as f:
        schema = json.load(f)
    jsonschema.validate(instance=fm, schema=schema)
```

## Conventions

- All file I/O uses atomic_write.
- All JSON output uses `sort_keys=True, indent=2, ensure_ascii=False` for deterministic, diff-friendly output.
- All YAML output uses `default_flow_style=False, sort_keys=True`.
- Errors include the offending file path and field name.
- Exit codes: 0 success, 2 validation error, 3 I/O error, 4 internal error.

## Unpack instructions

(For future sub-agents; Phase 1 handled by Foreman directly.)

1. Read this entire stub including frontmatter.
2. Read all `context_files`.
3. Confirm `embedded_questions` Q1 and Q5 conditions can be met.
4. Build per file layout above.
5. Run on EBB-01-001 sample (created in STUB-PHASE-01-S02).
6. Verify all six projections appear in `projections/`.
7. Compute SHA256 of each projection, run again, compare hashes — must match.
8. Self-review against deliverables D1–D5.
9. Write evidence to `deliverables/PHASE-01-S01.md`.
10. Mark status `review`; submit to Foreman.
11. Foreman verifies; on pass, marks `satisfied`.

## Cross-references

- Schema this script validates against: `docs/schemas/canonical-asset.md` (to be created from `template_canonical_empty_v0.2.md`)
- Sister stubs: STUB-PHASE-01-S02 (sample input), STUB-PHASE-01-S03 (test harness)
- Phase gate: `stubs/PHASE-01/_gate.md`
