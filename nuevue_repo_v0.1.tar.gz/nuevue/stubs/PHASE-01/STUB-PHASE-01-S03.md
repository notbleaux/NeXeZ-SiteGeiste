---
stub_id: "STUB-PHASE-01-S03"
phase: 1
phase_name: "Schema lock + first canonical sample"
title: "Round-trip integrity test harness"

status: "sealed"
priority: "P0"

agent_assignment:
  primary: "claude_foreman"
  sub_agents: []
  arbiter: "claude_foreman"

depends_on: ["STUB-PHASE-01-S01", "STUB-PHASE-01-S02"]
unblocks: ["STUB-PHASE-01-S04", "STUB-PHASE-02-S01"]

deliverables:
  - id: "D1"
    title: "test_project.py exists with round-trip test"
    success_metric: "`pytest test/test_project.py -k roundtrip` passes 100%"
    failure_cases:
      - "Test file missing"
      - "Test fails on EBB-01-001 input"

  - id: "D2"
    title: "Body byte-equivalence verified"
    success_metric: "After build → reconstruction of canonical .md from JSON projection, body section is byte-identical to original"
    failure_cases:
      - "Whitespace drift"
      - "Encoding change"
      - "Line ending change"

  - id: "D3"
    title: "Frontmatter structural equivalence verified"
    success_metric: "After round-trip, frontmatter is structurally equivalent: same keys, same values, same types. Key order may differ."
    failure_cases:
      - "Field dropped"
      - "Type coercion (e.g. bool → string)"
      - "Value drift"

  - id: "D4"
    title: "Idempotency test passes"
    success_metric: "Running build twice on same input produces byte-identical projection files (verified by SHA256)"
    failure_cases:
      - "Hash mismatch on second run"
      - "Timestamp leakage into outputs"

  - id: "D5"
    title: "Negative tests cover ≥3 failure modes"
    success_metric: "Tests exist for: missing required field rejection, malformed YAML rejection, unknown enum value rejection — all assert exit code non-zero with specific error message"
    failure_cases:
      - "Negative tests absent"
      - "Negative tests pass on invalid input"

deliverables_file: "deliverables/PHASE-01-S03.md"

gate_at_phase: "PHASE-01"

estimated_effort: "1 session"
opened_at: null
in_progress_at: null
review_at: null
satisfied_at: null
sealed_complete_at: null

version: "0.1"
revision_history: []

sub_agent_runs: []
arbiter_signoff:
  signed: false
  by: null
  at: null
  notes: ""
human_signoff:
  signed: false
  by: null
  at: null

context_files:
  - "stubs/PHASE-01/STUB-PHASE-01-S01.md"
  - "stubs/PHASE-01/STUB-PHASE-01-S02.md"
  - "docs/architecture/sator-framework.md"

embedded_questions:
  - question_id: "Q2"
    question: "Round-trip integrity definition"
    conditions:
      - "Body byte-identical after round-trip"
      - "Frontmatter structurally equivalent (key order may differ, types preserved, no value drift)"
      - "Passes on EBB-01-001 100% of runs"
      - "Negative test cases (intentionally malformed inputs) all rejected with non-zero exit"
    resolved: false
    resolution: ""
---

# STUB-PHASE-01-S03 — Round-trip integrity test harness

## Purpose

Establish automated proof that the build pipeline preserves canonical content fidelity. Round-trip integrity is the contract that lets us trust the projection layer indefinitely.

## What "round-trip" means

`canonical.md → build → projections → reconstruct → canonical.md'`

Where `canonical.md` and `canonical.md'` must satisfy:
- **Body section:** byte-identical (no whitespace, encoding, or line-ending drift).
- **Frontmatter:** structurally equivalent — same keys, same scalar values, same types, same list contents and order. Key order in the YAML output may differ; that is the only allowed variance.

## Test cases (minimum)

```python
# test/test_project.py
import subprocess, json, hashlib, pathlib, pytest, yaml

LIBRARY = pathlib.Path("library")
PROJECTIONS = pathlib.Path("projections")

def sha256(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def test_roundtrip_body_byte_equivalent():
    # Build
    subprocess.run(["python", "-m", "build.project",
                    "--input", "library/EBB-01-001.md",
                    "--output", "projections/"], check=True)
    # Reconstruct
    sidecar = json.loads((PROJECTIONS / "EBB-01-001.json").read_text())
    original_body = extract_body(LIBRARY / "EBB-01-001.md")
    reconstructed_body = sidecar["text"]
    assert original_body == reconstructed_body

def test_roundtrip_frontmatter_structural():
    sidecar = json.loads((PROJECTIONS / "EBB-01-001.json").read_text())
    original_fm, _ = parse_canonical((LIBRARY / "EBB-01-001.md").read_text())
    # All keys must round-trip
    assert set(original_fm.keys()) == set(sidecar.keys()) - {"text"}  # text is body
    # All values must round-trip
    for k in original_fm:
        if k != "text":
            assert sidecar[k] == original_fm[k], f"Field drift in {k}"

def test_idempotency_byte_identical():
    h1 = sha256(PROJECTIONS / "EBB-01-001.json")
    subprocess.run(["python", "-m", "build.project",
                    "--input", "library/EBB-01-001.md",
                    "--output", "projections/"], check=True)
    h2 = sha256(PROJECTIONS / "EBB-01-001.json")
    assert h1 == h2

def test_rejects_missing_required_field(tmp_path):
    bad = tmp_path / "bad.md"
    bad.write_text("---\nasset_id: ''\n---\nbody")  # missing required fields
    r = subprocess.run(["python", "-m", "build.project",
                        "--input", str(bad), "--output", str(tmp_path)],
                       capture_output=True)
    assert r.returncode == 2
    assert b"missing required" in r.stderr.lower() or b"required" in r.stderr.lower()

def test_rejects_malformed_yaml(tmp_path):
    bad = tmp_path / "bad.md"
    bad.write_text("---\n[invalid yaml\n---\nbody")
    r = subprocess.run(["python", "-m", "build.project",
                        "--input", str(bad), "--output", str(tmp_path)],
                       capture_output=True)
    assert r.returncode != 0

def test_rejects_unknown_enum_value(tmp_path):
    bad = tmp_path / "bad.md"
    bad.write_text("---\nasset_id: 'X'\nset: 'Q'\n...\n---\nbody")  # 'Q' not in [A,B,C,U]
    r = subprocess.run(["python", "-m", "build.project",
                        "--input", str(bad), "--output", str(tmp_path)],
                       capture_output=True)
    assert r.returncode == 2
```

## Conventions

- Tests live in `test/`.
- Use pytest.
- Test file mirrors module structure.
- Use `tmp_path` fixture for temp inputs to avoid polluting `library/`.
- Negative tests must assert specific exit codes and error message substrings.

## Unpack instructions

1. Read STUB-PHASE-01-S01 (build script) and STUB-PHASE-01-S02 (sample file).
2. Confirm both deliverables are satisfied; if not, escalate.
3. Write tests per minimum case set above.
4. Run `pytest test/ -v` — all pass.
5. Self-review D1–D5.
6. Write evidence to `deliverables/PHASE-01-S03.md`.
7. Submit to Foreman.

## Cross-references

- Producer stub: STUB-PHASE-01-S01
- Sample input: STUB-PHASE-01-S02
- Phase gate: `stubs/PHASE-01/_gate.md`
