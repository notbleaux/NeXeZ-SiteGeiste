---
stub_id: "STUB-PHASE-01-S02"
phase: 1
phase_name: "Schema lock + first canonical sample"
title: "Author EBB-01-001 canonical .md"

status: "sealed"
priority: "P0"

agent_assignment:
  primary: "claude_foreman"
  sub_agents: []
  arbiter: "claude_foreman"

depends_on: []  # can run in parallel with S01
unblocks: ["STUB-PHASE-01-S03", "STUB-PHASE-02-S01"]

deliverables:
  - id: "D1"
    title: "library/EBB-01-001.md exists with valid frontmatter"
    success_metric: "File loads via parse_canonical without errors; all required schema fields present"
    failure_cases:
      - "Frontmatter malformed"
      - "Required field missing"
      - "Author display field contains real name (must be 'E.B.B.')"

  - id: "D2"
    title: "Author display = 'E.B.B.', persona_of = 'leBeauxBleaux'"
    success_metric: "frontmatter author.display == 'E.B.B.' and author.persona_of == 'leBeauxBleaux'"
    failure_cases:
      - "Real name 'Harry' anywhere in file"
      - "persona_of missing or wrong"

  - id: "D3"
    title: "Source path matches dossier"
    success_metric: "source_path == 'IMG_1876.PNG' (per dossier extraction record)"
    failure_cases:
      - "source_path mismatched"

  - id: "D4"
    title: "Body text matches dossier exactly"
    success_metric: "Body content (after frontmatter) == 'I wish to be loved, Failing that I wish to be kind.' (with appropriate line breaks per source)"
    failure_cases:
      - "Text drift from source"
      - "OCR errors introduced"

  - id: "D5"
    title: "Verification fields populated honestly"
    success_metric: "verifier_chain.producer.agent_id = 'foreman_phase01'; reviewer left null (S03 will verify); arbiter null until satisfaction"
    failure_cases:
      - "Self-marked satisfied"
      - "Verifier chain falsified"

deliverables_file: "deliverables/PHASE-01-S02.md"

gate_at_phase: "PHASE-01"

estimated_effort: "30 min"
opened_at: null
in_progress_at: null
review_at: null
satisfied_at: null
sealed_complete_at: null

version: "0.1"
revision_history: []

sub_agent_runs: []
arbiter_signoff:
  signed: false
  by: null
  at: null
  notes: ""
human_signoff:
  signed: false
  by: null
  at: null

context_files:
  - "../../template_canonical_empty_v0.2.md"
  - "/mnt/project/ebb_dossier_complete.docx"  # source for poem text + metadata
  - "/mnt/project/IMG_1876.PNG"  # source image (visual reference only; text from dossier)

embedded_questions: []
---

# STUB-PHASE-01-S02 — Author EBB-01-001 canonical .md

## Purpose

Create the first canonical asset file for the NueVue Library. This sample file will be the input to STUB-PHASE-01-S01 (build script) and STUB-PHASE-01-S03 (round-trip test).

## Source data (from ebb_dossier_complete.docx)

| Field | Value |
|---|---|
| poem_id | EBB-01-001 |
| poem_num | 1 |
| source_file | IMG_1876.PNG |
| title | Untitled |
| Body | "I wish to be loved, Failing that I wish to be kind." |

## Required frontmatter (filled values)

```yaml
asset_id: "EBB-01-001"
source_path: "IMG_1876.PNG"
set: "A"
subset: "poetry"
content_type: "poem"

author:
  display: "E.B.B."
  idk: "leBeauxBleaux"
  is_self: true
  persona_of: "leBeauxBleaux"

source:
  platform: "tumblr"
  url: "gwarbluh-blog.tumblr.com"
  permission_status: "own_work"
language: "en"
date_created: null
date_added: "2026-05-09"
date_extracted: "2026-05-09"

verified: false  # arbiter sets true after S03
verifier_chain:
  producer:
    agent_id: "foreman_phase01"
    persona_id: null
    vendor: "anthropic"
  reviewer:
    agent_id: null
    persona_id: null
    vendor: null
  arbiter: null
  human_approved: false

multi_ai_session_id: null

text: |
  I wish to be loved,
  Failing that I wish to be kind.

analysis:
  themes: []  # populated in Phase 6, not here
  motifs: []
  symbols: []
  key_ideas: []
  cross_references: []
  last_extracted_by:
    agent_id: null
    persona_id: null
    vendor: null
    date: null

reviews: []  # populated in Phase 6+

edit_proposals: []
edit_history: []

tags: []
notes: ""
display:
  visibility: "private_only"
```

## Body (mirror of `text:`)

```
I wish to be loved,
Failing that I wish to be kind.
```

## Conventions

- File path: `library/EBB-01-001.md`.
- Use exact YAML structure from `template_canonical_empty_v0.2.md`.
- No real-name values. Author display is the pen name `E.B.B.` only.
- The dossier records the author as the user (`is_self: true`). The persona_of field links to `leBeauxBleaux`.

## Unpack instructions

1. Read template `template_canonical_empty_v0.2.md`.
2. Populate fields per "Required frontmatter" above.
3. Write file atomically to `library/EBB-01-001.md`.
4. Validate against schema (using script from STUB-PHASE-01-S01 once that's built; or by manual schema check if S01 not yet ready).
5. Self-review against D1–D5.
6. Submit to Foreman.

## Cross-references

- Source dossier: `/mnt/project/ebb_dossier_complete.docx`
- Template: `template_canonical_empty_v0.2.md` (from prior turn artifacts)
- Sister stubs: STUB-PHASE-01-S01 (consumer), STUB-PHASE-01-S03 (verifier)
