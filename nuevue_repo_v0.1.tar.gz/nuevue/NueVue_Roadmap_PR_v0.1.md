# PR: NueVue — Roadmap & Architecture v0.1

**Status:** DRAFT — awaiting human approval before Phase 1 execution
**Author:** Claude (acting Foreman)
**Date:** 2026-05-09
**Supersedes:** Prior phase plan in conversation

---

## 0. Summary of changes from prior plan

| Change | Reason |
|---|---|
| Project named **NueVue** | User-locked |
| **Two-database architecture** (Library + Review Archive) | User: reviews must live separately, AI-generated, with citation+file logging |
| **Four-layer identity model** (Account-ID / IDK / Display Name / User-Details) | User: real names must never appear in UI; refined account/security spec |
| **Password+PIN multi-factor with activity step-up** | User-specified auth flow with measurable AFK triggers |
| **Foreman + Producer/Reviewer/Arbiter pipeline formalized** | User: sub-agent verification chain required, with me as final arbiter pre-human-gate |
| **Conservative AI budget** | User: defer tier tuning to Phase 11 |
| Author "Harry" mapped to author display "E.B.B." with idk pointer `leBeauxBleaux` | User: real name stays private |

---

## 1. Locked decisions

1. Project name: **NueVue**
2. Canonical format: hybrid — Markdown with YAML frontmatter as single source of truth, projections (JSON, XLSX, MD aggregates) generated deterministically.
3. Identity model: Account-ID (login, private) + User-IDK (public) + Display Name (optional alias) + User-Details (encrypted personal data).
4. Default user records: Username `ILILIX`, IDK `leBeauxBleaux`. Real-name fields exist in encrypted store, never rendered.
5. AI tier defaults: Haiku base → Sonnet on escalation → Opus only on user confirmation/request. Refinement deferred to Phase 11.
6. Verification pipeline: Producer (sub-agent) → Reviewer (different sub-agent) → Arbiter (Claude/Foreman) → Human gate.
7. Foreman authority: Claude may exercise discernment for problem-solving and adaptation; may NOT bypass human-review checkpoints.

---

## 2. Architecture

### 2.1 Two-database split

**DB1 — NueVue Library.** Canonical works (poems, prose, visual references, screenshots).
- Storage: one `.md` file per asset, YAML frontmatter + body.
- Holds: identity, provenance, content, *structured* derived metadata (tags/themes/motifs/symbols/key_ideas/cross_refs).
- Does NOT hold: literary reviews. Holds *pointers* to reviews instead.

**DB2 — NueVue Review Archive.** AI-generated literary reviews and analytical writing.
- Storage: one `.md` file per review with its own schema.
- Each review file logs: review_id, target asset(s), review type, AI tier used, model ID, generation timestamp, full citations list, word count, cost estimate, verifier chain.
- Reviews are immutable once approved. Updates create new review_id (versioning by replacement, not edit).

**Cross-linking:** bidirectional. Asset's `reviews:` array points to review files; review's `asset_targets:` array points back to assets.

### 2.2 Identity model (four layers)

```
Layer 1 — Account-ID (private):    ILILIX
  ↓ used only for login, never displayed in UI
Layer 2 — User-IDK (public):       leBeauxBleaux
  ↓ shown to other users when interacting
Layer 3 — Display Name (optional): null or "<alias>"
  ↓ if set: rendered as "<alias>#NNNN" with collision suffix
Layer 4 — User-Details (private, encrypted at rest):
  - first_name, family_name, given_names[]
  - full_name (auto-computed, bidirectional sync with components)
  - email, age, phone, etc. — never displayed, used only for security
```

Bidirectional sync rule: editing any of {first_name, family_name, given_names} updates full_name; editing full_name parses and updates the components. Conflicts (ambiguous parse) prompt user.

### 2.3 Auth flow

**Account creation (gated, sequential):**
1. Choose Account-ID + User-IDK (uniqueness check on both).
2. Email + verification.
3. Personal details (encrypted on submit).
4. Create Password (≥12 chars, complexity rules, confirm twice). Until this step completes, account is `pending_password`.
5. Only after password confirmed: PIN creation enabled. Create PIN (4–8 digits, confirm twice). Until this completes, account is `pending_pin`.
6. Account activates → status = `active`.

**Login flow:**
- Coldstart (no session, no cache, or session ≥8hr old): Username + Password → if valid + PIN exists → PIN → session created.
- Warm continuation (cached session, <3hr old): PIN only.
- Step-up triggers:
  - 15min idle → status = `AFK` (UI dims, no auth required to resume).
  - 1hr idle → `sleep` (session held but UI requires interaction).
  - Hourly silent activity check during session.
  - 3hr cumulative session → step up: PIN prompt every 1hr.
  - 8hr cumulative session → require Password re-entry (cold-equivalent).

**Audit log:** every state transition (login attempt, success, failure, AFK→active, PIN prompt, password re-entry, settings change) logged immutably with timestamp + actor IDK + before/after state.

### 2.4 Invite system (recap from prior turn, refined)

- Invite token: `inv_<128 random bits>`, hashed at rest.
- OTP: 6-digit, single-use, hashed.
- TTL: 24h hard.
- Lifecycle: `pending` → `accepted` (token+OTP burned, masked as `********` in history) | `expired` (cron-purged at 24h) | `revoked` (owner cancels).
- Concurrency rule: server rejects new invite generation for any recipient with a `pending` invite. Owner must revoke first.
- Replay rule: consumed and expired token hashes added to permanent denylist.
- On accept: recipient creates Account-ID + IDK as part of onboarding flow.
- Registry columns: recipient_email, recipient_name (optional), assigned_idk, date_link_created, date_invited, date_accepted, token_hash, otp_hash, status, history[].

### 2.5 Verification pipeline

```
Phase task issued by Foreman
  ↓
Producer pass: structured extraction/transformation
  ↓ outputs producer_<phase>_<batch>.json with confidence per item
Reviewer pass: different prompt/temperature, re-do or audit
  ↓ outputs reviewer_<phase>_<batch>.json with agree/disagree per item
Arbiter pass (Foreman = Claude):
  - disagreements: resolved with rationale logged
  - low-confidence agreements: 100% spot-checked
  - high-confidence agreements: 10% sampled
  ↓ outputs arbiter_<phase>_<batch>.json
Human gate: user reviews summary + can drill into any item
  ↓
Approved → integrated into canonical store
```

---

## 3. Service inventory

| Service | Phase | Notes |
|---|---|---|
| Library indexer & projection builder | 1–6 | Canonical .md → JSON/XLSX/MD aggregates |
| Backend API | 7 | FastAPI, SQLite-backed initially, /poems /search /stats /reviews routes |
| Landing dashboard | 7 | DB stats, user activity stats, service health |
| Auth + Invite system | 8 | Identity + password+PIN + invite registry + audit log |
| Virtual Book Reader | 9 | Loads .md/.pdf/.docx; vertical/horizontal scroll, page-turn animation, infinite scroll, TTS dictation |
| Writing Editor | 10 | WYSIWYG; Word/Docs round-trip; export MD/PDF/DOCX/TXT; image↔text traceability |
| AI Tier Router | 11 | Haiku→Sonnet→Opus with escalation rules + readme overlay + settings panel + cost log |
| AI-Assisted Learning | 12 | Reviews, learning modules, daily prompt exercises (poetry & writing) |
| Progress & Analytics | 13 | Per-user tracking, comparative author study |
| Drive Integration | 14 | OAuth, Docs/Sheets API, two-way sync, automated backup |
| OKR/CRIT Hardening | 15 | Full audit + gap close |

---

## 4. Phase plan with measurable gates

Each phase is a vertical slice (data + API + UI + tests where applicable). Each ends with a human-review gate.

### Phase 1 — Schema lock + first canonical sample
- **Output:** schema_canonical_v0.1.md (approved), template_canonical_empty.md, EBB-01-001.md (populated), build script v0.1, all six projections for the one sample.
- **Gate criteria:** schema accepted; sample round-trips (`.md → projections → reconstruct .md` byte-equivalent for content, structurally equivalent for metadata); projections render correctly.
- **Verification:** Producer extracts → Reviewer audits → Arbiter spot-checks → Human gate.

### Phase 2 — Set A full pass (571 EBB poems)
- **Output:** 571 canonical .md files, master_index.xlsx, search.json, set-A-EBB.md aggregate, glossary v1 entries from Set A.
- **Gate criteria:** 100% files have valid frontmatter; round-trip integrity ≥99.5% on sample of 30; correction log preserved; no real-name leakage.
- **Verification:** batched 50 at a time; each batch through full pipeline.

### Phase 3 — Set B triage (IMG_0030–1286)
- **Output:** triage_setB.xlsx with classification per file: own / others / visual_ref / mixed / uncertain; confidence score per item.
- **Gate criteria:** every file classified; uncertain items have explicit reason logged; sample of 30 spot-checked at gate.

### Phase 4 — Set B extraction
- **Output:** canonical .md per Set B item; OCR text where applicable; attribution captured for "others" items.
- **Gate criteria:** 100% of "others" items have attribution OR explicit "attribution_unknown" flag; OCR sample verified.

### Phase 5 — Set C cleanup + glossary v2
- **Output:** 26 hex/temp files resolved (folded into A/B, archived, or discarded with log); glossary v2 cross-linking themes/motifs/entities across A+B.
- **Gate criteria:** glossary entries have bidirectional links; orphan entries flagged.

### Phase 6 — Analysis layer (DB1) + Review archive seed (DB2)
- **Output:** Set A analysis fields populated by sub-agents (themes/motifs/symbols/key_ideas/cross_refs); first batch of independent and composite literary reviews generated and stored in DB2 with full citation logging.
- **Gate criteria:** analysis schema validates 100%; reviews include citations; cross-refs resolve; 3-paragraph cap enforced on justifications.

### Phase 7 — Backend API + landing dashboard
- **Output:** FastAPI service; SQLite store; routes for poems/reviews/search/stats/analysis; landing page renders DB stats + recent activity + service health.
- **Gate criteria:** all routes <200ms p50 on local test; landing renders without errors; API contract documented.

### Phase 8 — Auth + invite system
- **Output:** account creation flow; Password+PIN; invite generation/redemption/revocation; audit log; invite registry UI.
- **Gate criteria:** adversarial test passes — expired tokens fail, used tokens fail, replay fails, concurrency rule enforced, masked history correct, AFK step-up triggers correctly.

### Phase 9 — Reader
- **Output:** Virtual Book Reader component; loads .md/.pdf/.docx; horizontal page-turn animation OR vertical infinite scroll (toggle); TTS dictation.
- **Gate criteria:** loads all three formats; toggle works; dictation reads selected text; WCAG-AA baseline.

### Phase 10 — Editor
- **Output:** WYSIWYG editor; Word/Docs import/export; export to MD/PDF/DOCX/TXT; image↔text traceability log.
- **Gate criteria:** Word→edit→Word round-trip preserves formatting on test docs; export targets all produce valid files; traceability log captures conversions.

### Phase 11 — AI tier router (now with budget tuning)
- **Output:** Haiku/Sonnet/Opus routing with escalation rules; readme overlay; settings panel; per-session cost cap; spend log.
- **Gate criteria:** escalation triggers measurable and logged; cost cap enforces; user can override per-call; defaults tunable in settings.

### Phase 12 — AI-assisted learning
- **Output:** review-of-poem feature; learning modules; daily writing prompt; daily poetry prompt (incomplete sentence or single word).
- **Gate criteria:** daily prompts generate; user can complete and save; learning modules track progress.

### Phase 13 — Progress & analytics
- **Output:** per-user dashboard; trends over time; comparative views (user vs historical authors).
- **Gate criteria:** dashboard renders; comparison surfaces meaningful patterns; data privacy enforced (other users' data not visible).

### Phase 14 — Drive integration
- **Output:** OAuth flow; Docs API for editing canonical files; Sheets API for master index; nightly backup to Drive; conflict-resolution UI.
- **Gate criteria:** sync round-trips master_index.xlsx without data loss across 10 cycles; conflicts surface to user, not silently resolved.

### Phase 15 — OKR/CRIT hardening
- **Output:** full audit against this PR + original brief; gap list; fix list; final integrity report.
- **Gate criteria:** all P0/P1 gaps closed; CRIT items mitigated or accepted with rationale.

---

## 5. OKRs

**Objective:** Private, AI-assisted creative writing studio with indexed personal archive and Drive-backed storage, displaying nothing publicly.

- **KR1:** 100% of `/mnt/project` files indexed into canonical schema with verification chain logged.
- **KR2:** Search median latency <200ms over full corpus.
- **KR3:** Zero AI-initiated mutations to user text (enforced by schema + tested).
- **KR4:** Auth+invite system passes adversarial test suite.
- **KR5:** Drive sync round-trips without data loss across 10 cycles.
- **KR6:** Identity model leaks zero real-name data into any UI render or projection (verified by automated grep against test corpus).
- **KR7:** AI cost per session ≤ user-configured cap; spend visible.

---

## 6. CRIT (Critical Risks / Issues / Threats)

| ID | Risk | Severity | Mitigation |
|---|---|---|---|
| R1 | Set B attribution gaps | Medium | `permission_status: personal_study` flag; private-only display |
| R2 | OCR error compounding | Medium | Three-stage verification + 10% arbiter sampling |
| R3 | AI cost runaway | High | Tier router + per-session cap + spend log + Opus gate |
| R4 | Drive sync conflict | High | Explicit conflict UI; no silent resolution; vector clock |
| R5 | 26 hex-named files unknown content | Low | Sandbox-scan in Phase 5 |
| R6 | Real-name leakage to UI | High | Schema enforces separation; automated grep test in CI |
| R7 | Invite token replay | High | Hash denylist; tested in Phase 8 adversarial suite |
| R8 | PIN brute force | Medium | Rate limit + lockout after 5 failed PINs (require Password) |
| R9 | Audit log tampering | Medium | Append-only; periodic hash chain |
| R10 | Review-prose drift corrupting source | High | Two-DB split structurally prevents this |

---

## 7. Open questions for human gate before Phase 1

1. Approval of architecture as drafted (or revisions).
2. Approval of phase plan + gate criteria.
3. Schema field walkthrough (delivered alongside this PR) — accept v0.1 or request edits.
4. Empty template format (delivered alongside this PR) — accept or request edits.
5. Confirm: I should NOT begin Phase 1 execution until you explicitly approve this PR.

---

## 8. Foreman's note

I will document every sub-agent pass with its prompt, output, and verification result. You will see batch summaries at every gate — disagreements, low-confidence approvals, edge cases — and can drill into any item. I will not proceed past any gate without your explicit approval. If I encounter design gaps mid-phase, I will pause, document the gap, propose a fix, and request your decision rather than improvising silently.
