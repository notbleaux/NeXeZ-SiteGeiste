# SATOR Seed Framework — Specification v0.1

**Status:** Draft, pending user approval
**Date:** 2026-05-09
**Owner:** Claude (Foreman)

---

## 1. Concept

The SATOR framework is a stub-driven development methodology. The name nods to the SATOR square (the sower's palindrome). Stubs are **sealed seeds** containing the technical context an agent needs to execute a task; agents arrive at a stub, unpack the embedded context, satisfy the deliverables, and the stub is removed only when the phase gate clears.

**Core invariants:**

1. **Context lives in stubs, not in agents' heads.** When a sub-agent opens a stub, everything it needs to do the work — specs, code, conventions, references — is in the stub or files the stub points to.
2. **Stubs cannot self-satisfy.** Only the arbiter (Foreman) can mark a stub `satisfied`, and only after the matching deliverables file has every item checked off with evidence.
3. **Phase gates require everything.** A phase gate is closed unless every stub in the phase is `satisfied` AND every deliverables file checked off AND the human-approval flag set.
4. **Stubs are versioned.** Revisions create new versions; old versions stay in audit.
5. **The SATORtree is canonical.** Visualizations, to-do lists, and dependency analysis derive from the tree.

---

## 2. Stub anatomy

A stub is a Markdown file with YAML frontmatter and a body.

**Frontmatter (canonical, machine-validated):**
- `stub_id` — unique, format `STUB-PHASE-NN-SNN`
- `phase`, `phase_name`
- `title`
- `status` — sealed | opened | in_progress | review | satisfied | sealed_complete | deferred | scope_changed
- `priority` — P0 | P1 | P2 | P3
- `agent_assignment` — primary, sub_agents[], arbiter
- `depends_on` — list of stub_ids that must be satisfied first
- `unblocks` — list of stub_ids unlocked when this is satisfied
- `deliverables` — list of `{id, title, success_metric, failure_cases}`
- `deliverables_file` — path to evidence file
- `gate_at_phase` — phase gate this stub feeds
- `estimated_effort` — human-readable estimate
- `version`, `revision_history`

**Body (unpackable context, prose + code):**
- Technical specifications
- Code references and inline examples
- Conventions and constraints
- Cross-references to other stubs, schemas, and architecture docs
- Unpack instructions for sub-agents
- Embedded technical questions where applicable

---

## 3. Stub lifecycle

```
[ sealed ]
   │ (agent opens stub for execution)
   ▼
[ opened ] — context unpacked, agent has read body
   │
   ▼
[ in_progress ] — agent producing output
   │
   ▼
[ review ] — Producer pass complete, Reviewer auditing
   │
   ▼
[ satisfied ] ← Arbiter (Foreman) signs off after verifying deliverables
   │
   ▼
[ sealed_complete ] — phase gate closed, stub archived
```

**Lateral states:**
- `deferred` — stub identified as not currently solvable; user must approve.
- `scope_changed` — requirements shifted; old version archived, new revision opens.

---

## 4. Deliverables files

Every stub has a matching file at `deliverables/PHASE-XX-SNN.md`. Format:

```yaml
---
deliverables_for_stub: STUB-PHASE-01-S01
items:
  - id: D1
    title: "build/project.py exists and runs"
    checked_off: false
    evidence: ""
    verified_by: ""
    verified_at: null
  - id: D2
    ...
all_checked: false
---

# Evidence Notebook for STUB-PHASE-01-S01

[Per-deliverable evidence: command output, file paths, test results, screenshots, etc.]
```

Stubs cannot be marked `satisfied` unless their deliverables file shows `all_checked: true` AND every item has non-empty `evidence`.

---

## 5. SATORtree

`stubs/_SATORtree.md` is the canonical map. Frontmatter holds version + checksum; body holds the structured tree.

**Tree contents:**
- Every phase listed.
- Every stub under its phase listed with current status.
- Dependencies between stubs explicit.
- Phase gates with their close criteria.

**Generated from the tree:**
- `stubs/_CanonicalToDo.md` — flat, prioritized to-do list.
- `docs/visualizations/satortree.mermaid` — graph rendering.
- `docs/visualizations/network-dependencies.mermaid` — dependency graph.

CI cycle-detects on the dependency graph; circular dependencies block merge.

---

## 6. Validation

`scripts/stub_validator.py` runs locally and in CI on every PR.

**Validation rules:**
1. Frontmatter YAML well-formed.
2. Required fields present.
3. `stub_id` matches filename.
4. `status` value valid.
5. `depends_on` references resolve to real stubs.
6. `deliverables_file` path exists.
7. If `status: satisfied`, deliverables file shows `all_checked: true` and arbiter sign-off present.
8. No cycles in dependency graph.

**Failure categories caught:**
- Malformed frontmatter
- Missing required field
- Invalid status value
- Broken stub reference
- Missing deliverables file
- Premature satisfaction (status set without arbiter)
- Cyclic dependencies

---

## 7. Sub-agent interaction protocol

**On stub assignment:**
1. Agent receives `stub_id` only (not full content) from Foreman.
2. Agent reads stub via filesystem.
3. Agent unpacks context (frontmatter + body).
4. Agent confirms deliverables understood; if ambiguous, escalates to Foreman.
5. Status: `sealed` → `opened`.

**During execution:**
1. Agent produces output per deliverables.
2. Status: `opened` → `in_progress`.
3. Agent self-reviews against success metrics.
4. Status: `in_progress` → `review`.

**On reviewer pass:**
1. Different sub-agent audits.
2. Disagreements flagged for Foreman.
3. Agreements with high confidence: 10% sampled by Foreman.

**On Foreman arbitration:**
1. Foreman verifies all deliverables.
2. If all satisfied: writes evidence into deliverables file; marks stub `satisfied`.
3. If incomplete: returns to agent with corrections OR escalates to user.

**Logging:**
Every state transition logged to `audit/stub_lifecycle.log`:
- timestamp
- stub_id
- from_status → to_status
- actor (agent_id / foreman / user)
- vendor (if AI)
- tokens_used
- notes

---

## 8. Phase gates

A phase gate is a file: `stubs/PHASE-XX/_gate.md`.

```yaml
---
phase: 1
phase_name: "Schema lock + first canonical sample"
gate_status: "open"  # open | closed
required_stubs: [STUB-PHASE-01-S01, S02, S03, S04]
all_stubs_satisfied: false
all_deliverables_checked: false
human_approved: false
human_approved_by: null
human_approved_at: null
---
```

`gate_status: closed` only when all three flags true.

**Phase progression rule:** Phase N+1 stubs cannot move from `sealed` to `opened` until Phase N's gate is closed. (Soft rule; Foreman can override with user approval for parallelizable cases, logged.)

---

## 9. Visualizations

Five canonical visualizations live in `docs/visualizations/` as Mermaid files:

| File | Purpose |
|---|---|
| `satortree.mermaid` | Tree view of phases → stubs |
| `gantt.mermaid` | Timeline of all 18 phases |
| `flowchart-stub-lifecycle.mermaid` | Stub state machine |
| `sankey-token-flow.mermaid` | Token economics flow (vendor → category → cost) |
| `network-dependencies.mermaid` | Stub dependency graph |

All are regenerated from the SATORtree on every PR via CI hook (Phase 7+).

---

## 10. Sunday scheduled jobs

Two jobs run Sunday under PINR `scheduled_job` authorization (pre-approved by user):

**Job 1 — Async Security & Codebase Audit (Sunday ~10:00 AEST)**
- Single async agent (Kimi or Deepseek by availability).
- Scans: dependency vulnerabilities, schema drift, stub-vs-tree consistency, broken cross-references, audit-log integrity.
- Output: `audit/sunday_<YYYY-WW>_security.md`.

**Job 2 — Mass Sub-Agent Codebase Check (Sunday ~14:00 AEST)**
- Parallel sub-agents (Kimi swarm).
- Each takes a subsystem slice (Auth, AI Service Layer, Library, Reviews, Bots, etc.).
- Output: per-slice review files compiled into `audit/sunday_<YYYY-WW>_codebase.md`.

**End-of-Week Review (Sunday 23:11 AEST)**
- Foreman compiles results from both jobs + the week's PR activity.
- Writes `audit/sunday_<YYYY-WW>_dev_review.md`.
- Surfaces in dashboard.
- Distinct from the Token Economics weekly review at Sunday 01:11 AEST.

---

## 11. GitHub workflow

**Branching:**
- `main` — protected; only PR merges.
- `phase-NN/<short-name>` — phase work branches.
- `stub/<stub_id>` — individual stub branches.

**PRs:**
- Use `.github/PULL_REQUEST_TEMPLATE.md`.
- Required checks: stub validation, schema validation, tests passing.
- Reviewer (Foreman) sign-off required.

**Issues:**
- One issue per stub (linked via stub_id).
- Issue closes when stub reaches `sealed_complete`.

**CI workflows:**
- `ci.yml` — tests, linting.
- `stub-validation.yml` — runs validator on every PR.
- `weekly-review.yml` — triggered Sunday, runs review jobs.

---

## 12. Open questions for user approval

1. Approve framework as drafted? Specific edits?
2. Approve Sunday scheduled jobs (security + mass sub-agent + dev review)?
3. GitHub credentials — push from your account; provide PAT/SSH or push manually after I prepare repo?
4. Stub creation cadence after approval — flesh all 18 phases now, or just Phase 1 fully + Phase 2-18 skeletons (recommended)?
5. Visualization rendering — Mermaid in markdown for now (renderable in any Mermaid-aware viewer); upgrade to SVG snapshots later when website exists?
