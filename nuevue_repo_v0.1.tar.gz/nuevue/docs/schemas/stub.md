# Stub Schema v0.1

## Frontmatter (canonical)

```yaml
---
stub_id: ""                       # required, unique, format: STUB-PHASE-NN-SNN
phase: 0                          # required, integer 1-18
phase_name: ""                    # required, human-readable phase name
title: ""                         # required, short title

status: "sealed"                  # sealed | opened | in_progress | review | satisfied | sealed_complete | deferred | scope_changed
priority: "P1"                    # P0 | P1 | P2 | P3

# AGENT ASSIGNMENT
agent_assignment:
  primary: "claude_foreman"
  sub_agents:
    - id: ""
      role: ""                    # description of what this sub-agent does
      vendor_preference: []       # ranked list, e.g. [kimi, claude_sonnet, deepseek]
      output: ""                  # path or description of expected output
  arbiter: "claude_foreman"

# DEPENDENCIES
depends_on: []                    # [stub_id, ...]
unblocks: []                      # [stub_id, ...]

# DELIVERABLES (must satisfy all to remove stub)
deliverables:
  - id: "D1"
    title: ""
    success_metric: ""            # measurable, testable
    failure_cases: []             # explicit anti-conditions
deliverables_file: ""             # path: deliverables/PHASE-XX-SNN.md

# GATE LINKAGE
gate_at_phase: ""                 # which phase gate this feeds

# TIMELINE
estimated_effort: ""              # e.g. "1 session", "1 day"
opened_at: null
in_progress_at: null
review_at: null
satisfied_at: null
sealed_complete_at: null

# VERSIONING
version: "0.1"
revision_history: []              # [{version, date, change_summary, by}, ...]

# AUDIT
sub_agent_runs: []                # [{run_id, agent_id, vendor, started, ended, tokens, outcome}, ...]
arbiter_signoff:
  signed: false
  by: null
  at: null
  notes: ""
human_signoff:
  signed: false
  by: null
  at: null

# CONTEXT POINTERS (other files this stub depends on for context)
context_files: []                 # paths to schemas, architecture docs, code references

# EMBEDDED TECHNICAL QUESTIONS (the 5 questions land here when relevant)
embedded_questions: []            # [{question_id, question, conditions[], resolved, resolution}, ...]
---

# Stub body — unpackable context

[Prose explanation of what needs to be done, why, and how it fits.]

## Technical specifications

[Concrete specs: languages, frameworks, libraries, file paths, naming conventions.]

## Code references and examples

[Inline code snippets, references to existing files, links to upstream docs.]

## Conventions

[Style guides, idempotency requirements, atomic-write rules, etc.]

## Unpack instructions for sub-agents

[Numbered steps an agent should follow when arriving at this stub.]

## Cross-references

[Links to related stubs, schemas, architecture docs.]
```

## Validation rules

1. `stub_id` must match filename (e.g. `STUB-PHASE-01-S01.md` ↔ `stub_id: STUB-PHASE-01-S01`).
2. `status` must be from the enum.
3. `depends_on` references must resolve to existing stubs.
4. `deliverables_file` path must exist.
5. If `status: satisfied`, `arbiter_signoff.signed` must be true AND deliverables file must show `all_checked: true`.
6. No cycles in `depends_on` graph.
7. Every `deliverables[].success_metric` must be testable (concrete, observable).
8. `priority` P0 stubs must have `estimated_effort` filled in.
