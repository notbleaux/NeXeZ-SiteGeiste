# Pull Request

## Stub reference

- **Stub ID:** STUB-PHASE-NN-SNN
- **Phase:** N — [phase name]
- **Status transition:** sealed → opened / opened → in_progress / etc.

## Summary

<!-- 1-2 sentences describing what this PR delivers. -->

## Deliverables addressed

<!-- Tick the deliverables this PR satisfies. Reference deliverable IDs from the stub. -->
- [ ] D1 — [title]
- [ ] D2 — [title]

## Evidence

<!-- Link to deliverables/PHASE-NN-SNN.md updates, test outputs, screenshots, etc. -->

## Sub-agent runs (if any)

| Run ID | Agent | Vendor | Tokens | Outcome |
|---|---|---|---|---|

## Verification chain

- Producer: 
- Reviewer: 
- Arbiter: claude_foreman (sign-off pending)
- Human approval: pending Phase gate review

## Checklist

- [ ] Stub validation passes (CI)
- [ ] Schema validation passes (CI)
- [ ] Tests passing (CI)
- [ ] Deliverables file updated with evidence
- [ ] No real-name leakage (grep verified)
- [ ] Audit log entry written

## Cost

Estimated tokens consumed: ~XXX  
Logged to: analytics/<week>.md

## Notes / anomalies

<!-- Any unexpected behavior, decisions made, or items to flag for review. -->
