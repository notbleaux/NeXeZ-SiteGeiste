---
name: New Stub
about: Create a new SATOR stub for a task
title: '[STUB] STUB-PHASE-NN-SNN: <short title>'
labels: stub
---

## Stub frontmatter draft

```yaml
stub_id: "STUB-PHASE-NN-SNN"
phase: N
phase_name: ""
title: ""
status: "sealed"
priority: "P1"
agent_assignment:
  primary: "claude_foreman"
  sub_agents: []
  arbiter: "claude_foreman"
depends_on: []
unblocks: []
deliverables: []
deliverables_file: "deliverables/PHASE-NN-SNN.md"
gate_at_phase: "PHASE-NN"
estimated_effort: ""
```

## Body / unpackable context

<!-- Technical specs, code refs, conventions, unpack instructions. -->

## Why this stub exists

<!-- The problem it solves and where it fits in the SATORtree. -->
