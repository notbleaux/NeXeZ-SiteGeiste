# NueVue

Private, AI-assisted creative writing studio. Live-service framework. Audience: user only.

## What this is

NueVue is a personal Discord-shaped studio with Notion-style content pages, a multi-vendor AI service layer, and a stub-driven (SATOR) development framework. It indexes, reviews, and helps grow a private literary corpus (own work + others studied privately).

## Repo structure

```
nuevue/
├── README.md                       # this file
├── .github/                        # PR templates, issue templates, CI workflows
├── docs/
│   ├── architecture/               # core architecture specs
│   ├── schemas/                    # canonical schemas (assets, reviews, stubs, etc.)
│   └── visualizations/             # SATORtree, Gantt, flowchart, Sankey (mermaid)
├── stubs/                          # task contracts (SATOR seeds)
│   ├── _SATORtree.md               # canonical tree of all stubs
│   ├── _CanonicalToDo.md           # flat to-do list (regenerated)
│   └── PHASE-XX/                   # per-phase stub folders
├── deliverables/                   # evidence files (one per stub)
├── library/                        # canonical asset .md files (DB1)
├── reviews/                        # AI-generated review .md files (DB2)
├── projections/                    # generated outputs (json, xlsx, etc.)
├── analytics/                      # Token Economics partition
├── audit/                          # weekly audit + scheduled-job outputs
├── build/                          # build scripts and outputs
└── scripts/                        # validators, renderers, runners
```

## SATOR framework — quick orient

A **stub** is a sealed task contract with embedded technical spec, code references, deliverables, success metrics, failure cases, and sub-agent instructions. Stubs live under `stubs/PHASE-XX/`.

A stub progresses: `sealed` → `opened` → `in_progress` → `review` → `satisfied` → `sealed_complete`. The arbiter (Foreman) signs off `satisfied`. Stub removal is gated on the matching deliverables file having all items checked off with evidence.

The **SATORtree** at `stubs/_SATORtree.md` is the canonical map of all stubs and their dependencies. The **Canonical To-Do** at `stubs/_CanonicalToDo.md` is the flat list, regenerated from the tree on every change.

Phase gate = (all phase stubs satisfied) AND (all deliverables files checked off) AND (human-approved flag set on phase gate file).

## Documents to read in order

1. `docs/architecture/sator-framework.md` — SATOR seed framework spec
2. `NueVue_Roadmap_PR_v0.3.md` (in repo root or `docs/`) — product roadmap
3. `docs/schemas/stub.md` — stub schema
4. `stubs/_SATORtree.md` — canonical tree
5. `stubs/_CanonicalToDo.md` — what's next

## Privacy notes

- Real-name fields are stored encrypted at rest, never rendered in UI or projections.
- Author display for the EBB corpus is `"E.B.B."` with `persona_of` pointing to the user IDK.
- This repo is private. Invite-only sharing per the auth spec.
